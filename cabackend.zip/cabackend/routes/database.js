const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const pool = require('../config/db');  // ✅ YEH LINE ADD KARO
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

// Backup database
router.post('/backup', auth, async (req, res) => {
    try {
        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }

        const backupDir = path.join(__dirname, '..', 'backups');
        if (!fs.existsSync(backupDir)) {
            fs.mkdirSync(backupDir);
        }

        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupFile = path.join(backupDir, `backup_${timestamp}.sql`);
        
        // Using mysqldump command
        const command = `mysqldump -u ${process.env.DB_USER} -p${process.env.DB_PASSWORD} ${process.env.DB_NAME} > ${backupFile}`;
        
        exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(error);
                return res.status(500).json({ message: 'Backup failed' });
            }
            
            res.json({ 
                message: 'Database backup completed successfully',
                backupFile: backupFile
            });
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Restore database
router.post('/restore', auth, async (req, res) => {
    try {
        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }

        const { backupFile } = req.body;
        
        if (!backupFile || !fs.existsSync(backupFile)) {
            return res.status(400).json({ message: 'Backup file not found' });
        }
        
        // Using mysql command
        const command = `mysql -u ${process.env.DB_USER} -p${process.env.DB_PASSWORD} ${process.env.DB_NAME} < ${backupFile}`;
        
        exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(error);
                return res.status(500).json({ message: 'Restore failed' });
            }
            
            res.json({ message: 'Database restore completed successfully' });
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get database info
router.get('/info', auth, async (req, res) => {
    try {
        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }

        // Get table sizes
        const [tables] = await pool.query(`
            SELECT 
                table_name AS 'table',
                ROUND(((data_length + index_length) / 1024 / 1024), 2) AS 'size'
            FROM information_schema.TABLES 
            WHERE table_schema = ?
            ORDER BY (data_length + index_length) DESC
        `, [process.env.DB_NAME]);

        // Get backup history
        const backupDir = path.join(__dirname, '..', 'backups');
        let backups = [];
        
        if (fs.existsSync(backupDir)) {
            const files = fs.readdirSync(backupDir);
            backups = files.map(file => {
                const filePath = path.join(backupDir, file);
                const stats = fs.statSync(filePath);
                return {
                    name: file,  // ✅ Added name field
                    date: stats.mtime.toISOString(),
                    size: (stats.size / 1024 / 1024).toFixed(2) + ' MB',
                    status: 'Completed'
                };
            });
        }

        res.json({
            tables,
            backups,
            dbSize: tables.reduce((sum, table) => sum + parseFloat(table.size), 0).toFixed(2) + ' MB',
            lastBackup: backups.length > 0 ? backups[0].date : 'Never'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get database tables (for admin dashboard)
router.get('/tables', auth, async (req, res) => {
    try {
        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }

        const [tables] = await pool.query(`
            SELECT 
                table_name as name,
                table_rows as rows
            FROM information_schema.tables 
            WHERE table_schema = ?
            AND table_type = 'BASE TABLE'
        `, [process.env.DB_NAME]);
        
        res.json(tables);
    } catch (error) {
        console.error('Database tables error:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

// Get backup list (for admin dashboard)
router.get('/backups', auth, async (req, res) => {
    try {
        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }

        const backupDir = path.join(__dirname, '..', 'backups');
        let backups = [];
        
        if (fs.existsSync(backupDir)) {
            const files = fs.readdirSync(backupDir);
            backups = files.map(file => {
                const filePath = path.join(backupDir, file);
                const stats = fs.statSync(filePath);
                return {
                    id: file,
                    name: file,
                    date: stats.mtime,
                    size: (stats.size / 1024 / 1024).toFixed(2) + ' MB',
                    status: 'completed'
                };
            });
        }
        
        res.json(backups);
    } catch (error) {
        console.error('Backup list error:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

module.exports = router;