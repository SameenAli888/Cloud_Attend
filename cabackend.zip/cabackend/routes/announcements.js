const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const auth = require('../middleware/auth');

// Get announcements
router.get('/', auth, async (req, res) => {
    try {
        let query = 'SELECT a.*, u.name as created_by_name FROM announcements a JOIN users u ON a.created_by = u.id';
        let params = [];
        
        // If user is a student, only get announcements for them
        if (req.user.role === 'student') {
            query += ` WHERE a.target_audience = 'all' OR a.target_audience = 'students' OR 
                      (a.target_audience = 'specific' AND a.target_courses IN (
                          SELECT course_id FROM user_courses WHERE user_id = ?
                      ))`;
            params = [req.user.id];
        }
        // If user is faculty, only get announcements for them
        else if (req.user.role === 'faculty') {
            query += ` WHERE a.target_audience = 'all' OR a.target_audience = 'faculty' OR 
                      (a.target_audience = 'specific' AND a.target_courses IN (
                          SELECT id FROM courses WHERE faculty_id = ?
                      ))`;
            params = [req.user.id];
        }
        
        query += ' ORDER BY a.created_at DESC';
        
        const [announcements] = await pool.query(query, params);
        res.json(announcements);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Create announcement (faculty and admin only)
router.post('/', auth, async (req, res) => {
    try {
        if (req.user.role !== 'faculty' && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        const { title, content, targetAudience, targetCourses } = req.body;
        
        const [result] = await pool.query(
            'INSERT INTO announcements (title, content, target_audience, target_courses, created_by) VALUES (?, ?, ?, ?, ?)',
            [title, content, targetAudience, JSON.stringify(targetCourses || []), req.user.id]
        );
        
        res.status(201).json({ 
            message: 'Announcement created successfully',
            announcementId: result.insertId
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Update announcement (faculty and admin only)
router.put('/:id', auth, async (req, res) => {
    try {
        if (req.user.role !== 'faculty' && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        const { title, content, targetAudience, targetCourses } = req.body;
        
        // Check if announcement exists and user has permission
        const [announcements] = await pool.query(
            'SELECT * FROM announcements WHERE id = ?',
            [req.params.id]
        );
        
        if (announcements.length === 0) {
            return res.status(404).json({ message: 'Announcement not found' });
        }
        
        // Faculty can only update their own announcements
        if (req.user.role === 'faculty' && announcements[0].created_by !== req.user.id) {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        await pool.query(
            'UPDATE announcements SET title = ?, content = ?, target_audience = ?, target_courses = ? WHERE id = ?',
            [title, content, targetAudience, JSON.stringify(targetCourses || []), req.params.id]
        );
        
        res.json({ message: 'Announcement updated successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Delete announcement (faculty and admin only)
router.delete('/:id', auth, async (req, res) => {
    try {
        if (req.user.role !== 'faculty' && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        // Check if announcement exists and user has permission
        const [announcements] = await pool.query(
            'SELECT * FROM announcements WHERE id = ?',
            [req.params.id]
        );
        
        if (announcements.length === 0) {
            return res.status(404).json({ message: 'Announcement not found' });
        }
        
        // Faculty can only delete their own announcements
        if (req.user.role === 'faculty' && announcements[0].created_by !== req.user.id) {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        await pool.query('DELETE FROM announcements WHERE id = ?', [req.params.id]);
        
        res.json({ message: 'Announcement deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;