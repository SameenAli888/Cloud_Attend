const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const auth = require('../middleware/auth');

// Get assignments by course
router.get('/course/:courseId', auth, async (req, res) => {
    try {
        const [assignments] = await pool.query(
            'SELECT * FROM assignments WHERE course_id = ?',
            [req.params.courseId]
        );
        res.json(assignments);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Create assignment
router.post('/', auth, async (req, res) => {
    try {
        if (req.user.role !== 'faculty') {
            return res.status(403).json({ message: 'Access denied' });
        }

        const { title, description, courseId, dueDate } = req.body;

        const [result] = await pool.query(
            'INSERT INTO assignments (title, description, course_id, due_date) VALUES (?, ?, ?, ?)',
            [title, description, courseId, dueDate]
        );

        res.status(201).json({ 
            message: 'Assignment created successfully',
            assignmentId: result.insertId
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;