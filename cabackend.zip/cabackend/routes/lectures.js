const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const auth = require('../middleware/auth');

// Get lectures for student
router.get('/student', auth, async (req, res) => {
    try {
        const [lectures] = await pool.query(
            `SELECT l.*, c.name as course_name 
             FROM lectures l
             INNER JOIN courses c ON l.course_id = c.id
             INNER JOIN user_courses uc ON c.id = uc.course_id
             WHERE uc.user_id = ?
             ORDER BY l.created_at DESC`,
            [req.user.id]
        );
        res.json(lectures);
    } catch (error) {
        console.error('Get student lectures error:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

// Get lectures for faculty
router.get('/faculty', auth, async (req, res) => {
    try {
        const [lectures] = await pool.query(
            `SELECT l.*, c.name as course_name 
             FROM lectures l
             INNER JOIN courses c ON l.course_id = c.id
             WHERE c.faculty_id = ?
             ORDER BY l.created_at DESC`,
            [req.user.id]
        );
        res.json(lectures);
    } catch (error) {
        console.error('Get faculty lectures error:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

// Create lecture
router.post('/', auth, async (req, res) => {
    try {
        const { title, description, video_url, course_id } = req.body;
        
        const [result] = await pool.query(
            'INSERT INTO lectures (title, description, video_url, course_id) VALUES (?, ?, ?, ?)',
            [title, description, video_url, course_id]
        );
        
        res.status(201).json({ id: result.insertId, message: 'Lecture created successfully' });
    } catch (error) {
        console.error('Create lecture error:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

module.exports = router;