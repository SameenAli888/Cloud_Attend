const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const auth = require('../middleware/auth');

// Get attendance records
router.get('/', auth, async (req, res) => {
    try {
        let query = 'SELECT a.*, u.name as student_name, c.name as course_name FROM attendance a JOIN users u ON a.student_id = u.id JOIN courses c ON a.course_id = c.id';
        let params = [];
        
        // If user is a student, only get their own attendance
        if (req.user.role === 'student') {
            query += ' WHERE a.student_id = ?';
            params = [req.user.id];
        }
        // If user is faculty, only get attendance for their courses
        else if (req.user.role === 'faculty') {
            query += ' WHERE c.faculty_id = ?';
            params = [req.user.id];
        }
        
        query += ' ORDER BY a.date DESC';
        
        const [attendance] = await pool.query(query, params);
        res.json(attendance);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get attendance by course
router.get('/course/:courseId', auth, async (req, res) => {
    try {
        const courseId = req.params.courseId;
        
        // Check if user has access to this course
        if (req.user.role === 'student') {
            const [enrollments] = await pool.query(
                'SELECT * FROM user_courses WHERE user_id = ? AND course_id = ?',
                [req.user.id, courseId]
            );
            
            if (enrollments.length === 0) {
                return res.status(403).json({ message: 'Access denied' });
            }
        } else if (req.user.role === 'faculty') {
            const [courses] = await pool.query(
                'SELECT * FROM courses WHERE id = ? AND faculty_id = ?',
                [courseId, req.user.id]
            );
            
            if (courses.length === 0) {
                return res.status(403).json({ message: 'Access denied' });
            }
        }
        
        const [attendance] = await pool.query(
            'SELECT a.*, u.name as student_name FROM attendance a JOIN users u ON a.student_id = u.id WHERE a.course_id = ? ORDER BY a.date DESC',
            [courseId]
        );
        
        res.json(attendance);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Mark attendance (faculty only)
router.post('/', auth, async (req, res) => {
    try {
        if (req.user.role !== 'faculty') {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        const { courseId, date, attendanceRecords } = req.body;
        
        // Check if course exists and user has permission
        const [courses] = await pool.query(
            'SELECT * FROM courses WHERE id = ? AND faculty_id = ?',
            [courseId, req.user.id]
        );
        
        if (courses.length === 0) {
            return res.status(404).json({ message: 'Course not found' });
        }
        
        // Mark attendance for each student
        for (const record of attendanceRecords) {
            await pool.query(
                'INSERT INTO attendance (student_id, course_id, date, status) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE status = ?',
                [record.studentId, courseId, date, record.status, record.status]
            );
        }
        
        res.json({ message: 'Attendance marked successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get attendance summary for a student
router.get('/summary/student/:studentId', auth, async (req, res) => {
    try {
        const studentId = req.params.studentId;
        
        // Students can only see their own summary
        if (req.user.role === 'student' && req.user.id !== parseInt(studentId)) {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        const [summary] = await pool.query(
            `SELECT 
                c.id as course_id,
                c.name as course_name,
                COUNT(*) as total_classes,
                SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_classes,
                ROUND(SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) as attendance_percentage
            FROM attendance a
            JOIN courses c ON a.course_id = c.id
            WHERE a.student_id = ?
            GROUP BY c.id, c.name`,
            [studentId]
        );
        
        res.json(summary);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;