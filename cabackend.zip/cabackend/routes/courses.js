const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const auth = require('../middleware/auth');

// Get all courses
router.get('/', auth, async (req, res) => {
    try {
        let query = 'SELECT * FROM courses';
        let params = [];
        
        // If user is a student, only get courses they're enrolled in
        if (req.user.role === 'student') {
            query = `
                SELECT c.* FROM courses c
                JOIN user_courses uc ON c.id = uc.course_id
                WHERE uc.user_id = ?
            `;
            params = [req.user.id];
        }
        // If user is faculty, only get courses they teach
        else if (req.user.role === 'faculty') {
            query = 'SELECT * FROM courses WHERE faculty_id = ?';
            params = [req.user.id];
        }
        
        const [courses] = await pool.query(query, params);
        res.json(courses);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get course by ID
router.get('/:id', auth, async (req, res) => {
    try {
        const [courses] = await pool.query('SELECT * FROM courses WHERE id = ?', [req.params.id]);
        
        if (courses.length === 0) {
            return res.status(404).json({ message: 'Course not found' });
        }
        
        res.json(courses[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Create course (faculty and admin only)
router.post('/', auth, async (req, res) => {
    try {
        if (req.user.role !== 'faculty' && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        const { name, description } = req.body;
        
        const [result] = await pool.query(
            'INSERT INTO courses (name, description, faculty_id) VALUES (?, ?, ?)',
            [name, description, req.user.id]
        );
        
        res.status(201).json({ 
            message: 'Course created successfully',
            courseId: result.insertId
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Update course (faculty and admin only)
router.put('/:id', auth, async (req, res) => {
    try {
        if (req.user.role !== 'faculty' && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        const { name, description } = req.body;
        
        // Check if course exists and user has permission
        const [courses] = await pool.query('SELECT * FROM courses WHERE id = ?', [req.params.id]);
        
        if (courses.length === 0) {
            return res.status(404).json({ message: 'Course not found' });
        }
        
        // Faculty can only update their own courses
        if (req.user.role === 'faculty' && courses[0].faculty_id !== req.user.id) {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        await pool.query(
            'UPDATE courses SET name = ?, description = ? WHERE id = ?',
            [name, description, req.params.id]
        );
        
        res.json({ message: 'Course updated successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Delete course (faculty and admin only)
router.delete('/:id', auth, async (req, res) => {
    try {
        if (req.user.role !== 'faculty' && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        // Check if course exists and user has permission
        const [courses] = await pool.query('SELECT * FROM courses WHERE id = ?', [req.params.id]);
        
        if (courses.length === 0) {
            return res.status(404).json({ message: 'Course not found' });
        }
        
        // Faculty can only delete their own courses
        if (req.user.role === 'faculty' && courses[0].faculty_id !== req.user.id) {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        await pool.query('DELETE FROM courses WHERE id = ?', [req.params.id]);
        
        res.json({ message: 'Course deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Enroll student in course
router.post('/:id/enroll', auth, async (req, res) => {
    try {
        if (req.user.role !== 'student') {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        const courseId = req.params.id;
        const studentId = req.user.id;
        
        // Check if course exists
        const [courses] = await pool.query('SELECT * FROM courses WHERE id = ?', [courseId]);
        
        if (courses.length === 0) {
            return res.status(404).json({ message: 'Course not found' });
        }
        
        // Check if already enrolled
        const [enrollments] = await pool.query(
            'SELECT * FROM user_courses WHERE user_id = ? AND course_id = ?',
            [studentId, courseId]
        );
        
        if (enrollments.length > 0) {
            return res.status(400).json({ message: 'Already enrolled in this course' });
        }
        
        // Enroll student
        await pool.query(
            'INSERT INTO user_courses (user_id, course_id) VALUES (?, ?)',
            [studentId, courseId]
        );
        
        res.json({ message: 'Enrolled successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;