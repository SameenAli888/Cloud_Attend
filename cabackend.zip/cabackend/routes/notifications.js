const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const auth = require('../middleware/auth');

// Get notifications
router.get('/', auth, async (req, res) => {
    try {
        const [notifications] = await pool.query(
            'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC',
            [req.user.id]
        );
        
        res.json(notifications);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Create notification (admin only)
router.post('/', auth, async (req, res) => {
    try {
        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }
        
        const { title, message, recipientType, recipientIds } = req.body;
        
        // If sending to all users of a specific type
        if (recipientType && !recipientIds) {
            let query = 'SELECT id FROM users';
            if (recipientType !== 'all') {
                query += ' WHERE role = ?';
            }
            
            const [users] = await pool.query(query, recipientType !== 'all' ? [recipientType] : []);
            
            for (const user of users) {
                await pool.query(
                    'INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                    [user.id, title, message]
                );
            }
        }
        // If sending to specific users
        else if (recipientIds && recipientIds.length > 0) {
            for (const userId of recipientIds) {
                await pool.query(
                    'INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                    [userId, title, message]
                );
            }
        }
        
        res.status(201).json({ message: 'Notifications sent successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Mark notification as read
router.put('/:id/read', auth, async (req, res) => {
    try {
        const [notifications] = await pool.query(
            'SELECT * FROM notifications WHERE id = ? AND user_id = ?',
            [req.params.id, req.user.id]
        );
        
        if (notifications.length === 0) {
            return res.status(404).json({ message: 'Notification not found' });
        }
        
        await pool.query(
            'UPDATE notifications SET is_read = 1 WHERE id = ?',
            [req.params.id]
        );
        
        res.json({ message: 'Notification marked as read' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Mark all notifications as read
router.put('/read-all', auth, async (req, res) => {
    try {
        await pool.query(
            'UPDATE notifications SET is_read = 1 WHERE user_id = ?',
            [req.user.id]
        );
        
        res.json({ message: 'All notifications marked as read' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;