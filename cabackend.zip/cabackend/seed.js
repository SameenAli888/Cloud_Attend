const pool = require('./config/db'); // aapka DB connection file

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function seedData() {
  try {
    // 1) Get all faculty and student users
    const [facultyUsers] = await pool.query("SELECT id, name FROM users WHERE role='faculty'");
    const [studentUsers] = await pool.query("SELECT id, name FROM users WHERE role='student'");

    // 2) Create 1 course per faculty
    for (let faculty of facultyUsers) {
      const [result] = await pool.query(
        'INSERT INTO courses (name, description, faculty_id) VALUES (?, ?, ?)',
        [`${faculty.name}'s Course`, `This is a course by ${faculty.name}`, faculty.id]
      );
      faculty.courseId = result.insertId; // store course id
      console.log(`Course created for faculty ${faculty.name} (ID: ${faculty.id})`);
    }

    // 3) Enroll each student in random 1-2 courses
    for (let student of studentUsers) {
      // Shuffle faculty list
      const shuffledFaculty = facultyUsers.sort(() => 0.5 - Math.random());
      const coursesToEnroll = shuffledFaculty.slice(0, getRandomInt(1, Math.min(2, facultyUsers.length)));

      for (let faculty of coursesToEnroll) {
        // Check if enrollment already exists
        const [existing] = await pool.query(
          'SELECT * FROM user_courses WHERE user_id = ? AND course_id = ?',
          [student.id, faculty.courseId]
        );
        if (existing.length === 0) {
          await pool.query(
            'INSERT INTO user_courses (user_id, course_id) VALUES (?, ?)',
            [student.id, faculty.courseId]
          );
        }

        // Add random attendance for 5 days
        for (let i = 0; i < 5; i++) {
          const status = Math.random() > 0.2 ? 'present' : 'absent';
          const date = new Date();
          date.setDate(date.getDate() - i); // past 5 days
          await pool.query(
            'INSERT INTO attendance (student_id, course_id, date, status) VALUES (?, ?, ?, ?)',
            [student.id, faculty.courseId, date, status]
          );
        }
      }

      console.log(`Student ${student.name} enrolled in courses and attendance added`);
    }

    console.log('✅ Enhanced seeding completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding data:', error);
    process.exit(1);
  }
}

seedData();
